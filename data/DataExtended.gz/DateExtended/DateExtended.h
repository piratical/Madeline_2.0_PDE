/////////////////////////////////////////////////////////
//
// This file is part of the MADELINE 2 program 
// written by Edward H. Trager and Ritu Khanna
// Copyright (c) 2005 by the
// Regents of the University of Michigan.
// All Rights Reserved.
// 
// The latest version of this program is available from:
// 
//   http://eyegene.ophthy.med.umich.edu/madeline/
//   
// Released under the GNU General Public License.
// A copy of the GPL is included in the distribution
// package of this software, or see:
// 
//   http://www.gnu.org/copyleft/
//   
// ... for licensing details.
// 
/////////////////////////////////////////////////////////
//
// 2005.03.27.ET
//

//
// date.h
//

#ifndef DATE_INCLUDED
#define DATE_INCLUDED

#include <time.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <limits.h>
#include <string.h>
#include <stdlib.h>
#include <iostream>

#include "Variable.h"
#include "NumberExtended.h"

//
// Date Class:
//
class Date : public Variable {
public:
	
	//
	// We use BUDDHIST_GREGORIAN here to emphasize that this
	// is not the lunar calendar but just the Gregorian with
	// years counted using the Buddhist Era convention:
	// 
	enum CALENDAR{ GREGORIAN, BUDDHIST_GREGORIAN, HIJRI };
	
	const static Date MISSING;
	
private:
	
	const static int _daysInMonth[12];
	
	// Private constants needed by algorithms:
	const static long _IGREG=(15+31L*(10+12L*1582)); // Gregorian calendar adopted Oct. 15, 1582 
	const static long _IGREGJULIAN = 2299161;        // Julian day number of Oct. 15m 1582
	//
	// The start (day 1 of Muharram, 1 AH) of the Hijri Islamic calendar  was 
	// Friday July 16, 622 CE, julianDay=1,948,440.  
	// As the calendar depends on Lunar sightings by a human (rather than 
	// astronomical calculations), it can go up or down a day.
	// By using two days before here, the algorithm based on Reingold and 
	// Dershowitz (see reference below) gives the correct dates and days of 
	// week for:
	// 
	//   Friday   0632.03.06 CE == 0010.12.09 AH
	//   Tuesday  1992.12.08 CE == 1413.06.13 AH
	//   Saturday 2005.03.26 CE == 1426.02.16 AH
	//   
	const static long _IHIJRIJULIAN = 1948438;       
	const static unsigned int _DATESTRINGLENGTH=10;  // Length of date string in yyyy.mm.dd or dd.mm.yyyy format
	const static double _DAYSINYEAR = 365.2425;      // Current (in year 2005) average no. of days per year
	
	// Private data:
	bool     _isMissing;                             // Boolean for missing
	bool     _isApproximate;
	bool     _isRange;
	long     _julian;                                // julian day number
	long     _highEndJulian;
	
	// STATIC MEMBER:
	static CALENDAR _calendarDisplayType;            // Default calendar
	
	//////////////////////
	//
	// Private methods:
	// 
	/////////////////////
	
	/// 
	/// Returns true if c is in the set "-./": 
	/// 
	bool _isDateDelimiter(char c);
	
	///
	/// Checks for errors in year yyyy, month mm, day dd
	/// for Gregorian civil calendar:
	/// 
	bool _yearMonthDayAreValid(int yyyy, int mm, int dd);
	
	///
	/// Converts Gregorian civil year yyyy, month mm, day dd 
	/// to Julian day number:
	///
	long _yearMonthDayToJulian(int yyyy,int mm, int dd);
	
	///
	/// Determines if a Gregorian calendar year is a leap year: 
	///
	bool Date::_isLeapYear(int year);
	
	///
	/// Obtain the Gregorian civil year yyyy, month mm, and day dd:
	///
	void _getYearMonthDay(const long julian, int *yyyy,int *mm,int *dd) const;
	
	//////////////////////////
	//
	// Islamic calendar stuff:
	//
	// Reference: 
	// "Calendrical Calculations'' by Nachum Dershowitz and
	// Edward M. Reingold, Software---Practice & Experience,
	// vol. 20, no. 9 (September, 1990), pp. 899--928.
	//
	//////////////////////////
	
	//
	// Obtain the Julian day number from an Islamic Hijri date:
	//
	long Date::_islamicYearMonthDayToJulian( int yyyy, int mm, int dd) const ;
	
	//
	// Returns true if it is an Islamic Hijri leap year:
	//
	bool _isIslamicLeapYear(int year) const;
	
	//
	// Returns the number of days in the Islamic month:
	//
	int _lastDayOfIslamicMonth(int year, int month) const ;
	
	//
	// _getIslamicYearMonthDay
	//
	// --> Only use if date is > IHIJRIJULIAN (start of Islamic calendar)
	//
	void Date::_getIslamicYearMonthDay(const long julian, int *yyyy, int *mm, int *dd) const;
	
public:
	
	// Methods required by virtual base class Variable:
	bool isMissing( void ) const;
	void setMissing( void );
	void set(const char *s);
	void set(const std::string &d);
	const std::string get( void ) const;
	
};

//
// Free Functions:
//
std::ostream& operator<<(std::ostream& s,const Date& d);

#endif

