/////////////////////////////////////////////////////////
//
// This file is part of the MADELINE 2 program 
// written by Edward H. Trager and Ritu Khanna
// Copyright (c) 2005 by the
// Regents of the University of Michigan.
// All Rights Reserved.
// 
// The latest version of this program is available from:
// 
//   http://eyegene.ophthy.med.umich.edu/madeline/
//   
// Released under the GNU General Public License.
// A copy of the GPL is included in the distribution
// package of this software, or see:
// 
//   http://www.gnu.org/copyleft/
//   
// ... for licensing details.
// 
/////////////////////////////////////////////////////////
//
// 2005.03.07.ET
//

#include "Warning.h"
#include "DigitConverter.h"

//
// Date.cpp
//
// Date class implementation
//
// Original implementation (c) 2003 Ed Trager
// Last revised: 2005.03.07.ET

#include "DateExtended.h"
#include <sstream>
#include <iomanip>


///////////////////////////////////
//
// STATIC AND CONST STATIC MEMBERS:
//
///////////////////////////////////

// Static days in month array:
const int Date::_daysInMonth[12]={31,28,31,30,31,30,31,31,30,31,30,31};

// Static _calendarDisplayType:
Date::CALENDAR Date::_calendarDisplayType = Date::GREGORIAN;

// MISSING Date:
const Date Date::MISSING;

//////////////////////////
//
// PRIVATE METHODS
//
//////////////////////////

//
// Check for date delimiters in date string:
//
bool Date::_isDateDelimiter(char c){
	
	return (c=='/' || c==',' || c=='.' || c==' ' || c=='-');
	
};

///
/// Checks for errors in year yyyy, month mm, day dd
/// for Gregorian civil calendar:
/// 
bool Date::_yearMonthDayAreValid(int yyyy, int mm, int dd){
	
	// Check if YEAR is valid:
	if(yyyy==0){
		//
		// There is no year zero in the Gregorian calendar:
		//
		Warning("%04i.%02i.%02i: There is no year zero in the Gregorian calendar, so the date has been set to missing.",yyyy,mm,dd);
		return false;
	}
	// Check if MONTH is valid:
	if(mm<1 || mm >12){
		Warning("%04i.%02i.%02i: The month is invalid, so the date has been set to missing.",yyyy,mm,dd);
		return false;
	}
	// Check if DAY is valid:
	if(dd <1){
		Warning("%04i.%02i.%02i: The day is invalid, so the date has been set to missing.",yyyy,mm,dd);
		return false;
	}
	if( mm==2 && _isLeapYear(yyyy)){
		if( dd>29 ){
			Warning("%04i.%02i.%02i: There are only 29 days in this month, so the date has been set to missing.",yyyy,mm,dd);
			return false;
		}
	}else if(dd > _daysInMonth[mm-1]){
		// Of course month array is zero-offset:
		Warning("%04i.%02i.%02i: There are only %i days in this month, so the date has been set to missing",yyyy,mm,dd,_daysInMonth[mm-1]);
		return false;
	}
	// Get here if everything is OK:
	return true;
	
}


///
/// Converts Gregorian civil year yyyy, month mm, day dd 
/// to Julian day number:
///
long Date::_yearMonthDayToJulian(int yyyy,int mm, int dd){
	
	int ja,jy,jm;
	int julianday;
	
	if(yyyy<0) yyyy++;
	if(mm>2){
		jy=yyyy;
		jm=mm+1;
	}else{
		jy=yyyy-1;
		jm=mm+13;
	}
	julianday=(long)(floor(365.25*jy)+floor(30.6001*jm)+dd+1720995);
	if(dd+31L*(mm+12L*yyyy)>=_IGREG){
		/*                                                             */
		/* Original code from Press et. al. does not show cast here,   */
		/* but assignment to 'int' from 'double' will generate warning */
		/* without cast:                                               */
		/*                                                             */
		ja=(int)(0.01*jy);
		julianday+= 2-ja+(int)(0.25*ja);
	}
	
	return julianday;
	
}

///
/// Determines if a Gregorian calendar year is a leap year: 
///
bool Date::_isLeapYear(int year){
	
	
	return ( (year%4==0) && (year%100!=0) ) || (year%400==0);
	
}

//
// _getYearMonthDay
//
void Date::_getYearMonthDay(const long julian, int *yyyy, int *mm, int *dd) const {

	long ja,jalpha,jb,jc,jd,je;
	
	if(julian >= _IGREGJULIAN){
		/*                                                                */
		/* Original code from Press et. al. does not show cast to         */
		/* long here, but missing that will generate warning on ANSI C++  */
		/* compilers:                                                     */
		/*                                                                */
		jalpha=(long)(((double)(_julian-1867216)-0.25)/36524.25);
		ja=julian+1+jalpha-(long)(0.25*jalpha);
	}else{
		ja=julian;
	}
	/*                                                              */
	/* Assignment to 'long int' from 'double' will generate warning */
	/* on ANSI C++ compilers:                                       */
	/*                                                              */
	jb=ja+1524;
	jc=(long)(6680.0+((double)(jb-2439870)-122.1)/365.25);
	jd=(long)(365*jc+(0.25*jc));
	je=(long)((jb-jd)/30.6001);
	*dd=jb-jd-(int)(30.6001*je);
	*mm=je-1;
	if(*mm>12) *mm-=12;
	*yyyy=jc-4715;
	if(*mm>2) --(*yyyy);
	if(*yyyy<=0) --(*yyyy);
	
	//
	// Correct year if using Buddhist calendar:
	// According to Thai Buddhism, Siddhartha Gotama 
	// reached nirvana 543 years before Jesus Christ
	// was born.  Thais now just use the Gregorian calendar, but with
	// years counted according to the Buddhist Era:
	//
	if( _calendarDisplayType == BUDDHIST_GREGORIAN ) *yyyy+=543;
	
}

//
// Obtain the Julian day number from an Islamic Hijri date:
//
long Date::_islamicYearMonthDayToJulian( int yyyy, int mm, int dd) const {
	
	return ( 
	           dd                     // days so far this month
	           + 29 * (mm - 1)        // days so far...
	           + mm/2                 // ...this year
	           + 354 * (yyyy - 1)     // non-leap days in prior years
	           + (3 + (11 * yyyy))/30 // leap days in prior years
	           + _IHIJRIJULIAN         // days before start of calendar
	       );
	       
}

//
// Returns true if it is an Islamic Hijri leap year:
//
bool Date::_isIslamicLeapYear(int year) const {
	
	return ((((11 * year) + 14) % 30) < 11);
	
}

//
// Returns the number of days in the Islamic month:
//
int Date::_lastDayOfIslamicMonth(int year, int month) const {
	
	if(((month % 2) == 1) || ((month == 12) && _isIslamicLeapYear(year))){
		return 30;
	}else{
		return 29;
	}
}

//
// _getIslamicYearMonthDay
//
// --> Only use if date is > _IHIJRIJULIAN (start of Islamic calendar)
//
void Date::_getIslamicYearMonthDay(const long julian, int *yyyy, int *mm, int *dd) const {
	
	int year, month, day;
	//
	// Search forward year by year from approximate year:
	//
	year = ( julian - _IHIJRIJULIAN )/355;
	while( julian >= _islamicYearMonthDayToJulian(year+1,1,1) ){
		year++;
	}
	//
	// Search forward month by month from Muharram:
	//
	month = 1;
	while( julian > _islamicYearMonthDayToJulian(year,month,_lastDayOfIslamicMonth(year,month) ) ){
		month++;
	}
	day = julian - _islamicYearMonthDayToJulian(year,month,1) + 1;
	// Finally, assign to return values:
	*yyyy=year;
	*mm  =month;
	*dd  =day;
	
}

//////////////////////////
//
// PUBLIC METHODS
//
//////////////////////////

//
// bool isMissing():
// Required by virtual base class:
//
bool Date::isMissing( void ) const {
	return _isMissing;
}

//
// Set a date from a "yyyy.mm.dd" string:
//
void Date::set(const char *dateString){
	
	//
	// Check if NULL:
	//
	if(!*dateString){
		_isMissing=true;
		_isApproximate=_isRange=false;
		_julian=0;
		return;
	}
	
	////// strlen(dateString)!=_DATESTRINGLENGTH){
	
	//
	// Use digit converter for handling the
	// possible case of non-ASCII digits:
	//
	const char *s = DigitConverter(dateString).get().c_str();
	
	//
	// Here we use some old-fashioned C-style code to
	// check the date format and obtain the year, month, and
	// day elements:
	//
	char hold[_DATESTRINGLENGTH+1];
	char *y,*m,*d;
	int yy,mm,dd;
	
	strncpy(hold,s,_DATESTRINGLENGTH);
	hold[_DATESTRINGLENGTH]='\0';
	
	//                                            
	// Check whether delimiters are at the correct
	// positions for reading YYYY.MM.DD:          
	//                       0123456789           
	//                                            
	//                                            
	if(_isDateDelimiter(s[4]) && _isDateDelimiter(s[7])){
		// YYYY.MM.DD pattern:
		hold[4]='\0'; // null-terminate so we can call atoi() in-place
		hold[7]='\0'; // ... ditto ...
		y=(char *)&hold;
		m=(char *)&hold+5;
		d=(char *)&hold+8;
		yy=atoi(y);
		mm=atoi(m);
		dd=atoi(d);
		_yearMonthDayToJulian(yy,mm,dd);
		
		_isApproximate=_isRange=false;
		
	}else{
		setMissing();
	}
	
}

//
// Set date from std::string:
//
void Date::set(const std::string &d){
	set(d.c_str());
}

//
// Get string representation of the date:
//
// UNFINISHED: ostringstream may be SLOW : test and change
//
const std::string Date::get( void ) const {
	
	std::ostringstream oss;
	if( _isMissing ){
		
		oss << "{.}";
		
	}else if(_calendarDisplayType==HIJRI && _julian< _IHIJRIJULIAN){
		
		Warning("The *display* of Islamic proleptic dates (i.e., before 0622.07.16 C.E.) has not been implemented.");
		oss << "{.}";
		
	}else{
		int yyyy,mm,dd;
		if(_calendarDisplayType==HIJRI){
			_getIslamicYearMonthDay(_julian,&yyyy,&mm,&dd);
		}else{
			_getYearMonthDay(_julian,&yyyy,&mm,&dd);
		}
		oss << '{' 
		    << std::setfill('0') << std::setw(4) << yyyy 
		    << '.' 
		    << std::setw(2) << mm 
		    << '.' 
		    << std::setw(2) << dd 
		    << '}' ;
	}
	
	return (const std::string) oss.str();
	
}


